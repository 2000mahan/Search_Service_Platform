# Security Policy

## Reporting a Vulnerability

Please report security issues to `nltk.team@gmail.com`
